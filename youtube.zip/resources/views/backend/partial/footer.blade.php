<footer>
    <div class="pull-right">
      Developed by <a href="">Md Faruk Ahamed & Md Shariful Islam</a>
    </div>
    <div class="clearfix"></div>
  </footer>


<div class="top">
    <ul>
        <li><a href="#" class="all">all</a></li>
        <li><a href="#">javascript</a></li>
        <li><a href="#">music</a></li>
        <li><a href="#">drama</a></li>
        <li><a href="#">live</a></li>
        <li><a href="#">afran niso</a></li>
        <li><a href="#">algorithm</a></li>
        <li><a href="#">news</a></li>
        <li><a href="#">website</a></li>
        <i class="fa-solid fa-angle-right" style=" margin-left: 30px;"></i>
    </ul>
</div>

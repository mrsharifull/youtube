<div class="flex-column-1">
    <div class="flex-column-conten-1">
        <ul>
            <li class="home"><i class="fa-solid fa-house" style="font-size: 18px;"></i><a href="{{route('home')}}" >home</a></li>
            <li class="shorts"><i class="fa-solid fa-play" style="font-size: 18px;"></i><a href="#">shorts</a></li>
            <li><i class="fa-solid fa-box" style="font-size: 18px;"></i><a href="#">subscription</a></li>
        </ul>
    </div>
    <div class="flex-column-conten-2">
        <ul>
            <li><i class="fa-solid fa-book" style="font-size: 18px;"></i><a href="#">library</a></li>
            <li><i class="fa-regular fa-clock" style="font-size: 18px;"></i><a href="#">history</a></li>
            <li><i class="fa-solid fa-file-video" style="font-size: 18px;"></i><a href="#">your vidoes</a></li>
            <li><i class="fa-solid fa-check" style="font-size: 18px;"></i><a href="#">watch later</a></li>
            <li><i class="fa-solid fa-clipboard" style="font-size: 18px;"></i><a href="#">your clip</a></li>
            <li><i class="fa-solid fa-angle-down" style="font-size: 18px;"></i><a href="#">show more</a></li>
        </ul>
    </div>
    <div class="flex-column-conten-3">

    </div>
</div>
